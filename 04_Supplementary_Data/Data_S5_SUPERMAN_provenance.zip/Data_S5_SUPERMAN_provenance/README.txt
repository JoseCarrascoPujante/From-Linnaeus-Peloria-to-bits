Supplementary Data S5. SUPERMAN/Wa-1 processing provenance

CONTENTS

SRR11805321.SUPERMAN_gene.CX_report.txt.gz   Wa1-Bs-Rep2
SRR11805322.SUPERMAN_gene.CX_report.txt.gz   Wa1-Bs-Rep1
SUPERMAN_analysis_summary.json               read counts per processing step and
                                             coverage statistics per replicate

Replicates were processed separately; their counts are not summed.

REGION

TAIR10 chromosome 3:8,242,256-8,243,372 (SUPERMAN/AT3G23130; 1-based,
inclusive; 1,117 bp). The chromosome is named "3". Processing used the
extended window 3:8,232,256-8,248,372 (gene plus 10 kb upstream and 5 kb
downstream); the "context" statistics in the JSON refer to that window and
the "gene" statistics to the interval above. The JSON also records the names
of intermediate files (BAM alignments, extended-window reports) that are not
part of this package.

FORMAT

Bismark cytosine reports, gzip-compressed, tab-separated, no header:
1 chromosome; 2 position (1-based); 3 strand; 4 methylated count;
5 unmethylated count; 6 context (CG, CHG, CHH); 7 reference trinucleotide
on the cytosine strand. Each report lists all 431 reference cytosines of
both strands (24 CG, 51 CHG, 356 CHH). A 0/0 row means no coverage. No
minimum coverage was applied.

PROCESSING

1. FASTQ files downloaded from ENA; size and official MD5 verified.
2. fastp 1.4.0: paired-end adapter trimming with additional adapter
   detection, poly-G trimming, 3' sliding-window trimming (4 bases, mean
   Q20), minimum length 35 nt, Q20 quality filter with at most 40%
   unqualified bases and 5 N per read; no base correction or pair merging.
3. Conservative prefilter against the extended window plus
   1 kb on each side, both orientations and C-to-T/G-to-A conversions;
   both mates kept when either could align with at most 10% converted
   differences. Ambiguous cases were passed to the aligner.
4. Bismark 0.25.1 with Bowtie2 2.5.5, end-to-end, competitive paired-end
   alignment to the complete TAIR10 genome (five chromosomes, mitochondrion
   and plastid): --non_directional -N 1 -L 20 -D 20 -R 3
   --score_min L,0,-0.6 -X 1000 --dovetail --strandID.
5. Primary, concordant, uniquely assigned pairs with MAPQ >= 20 in both
   mates, no clipping and at most 10% converted differences per mate
   (recomputed from CIGAR, reference and XG tag), overlapping the extended
   window.
6. deduplicate_bismark --paired.
7. bismark_methylation_extractor --paired-end --no_overlap --comprehensive
   --bedGraph --CX --cytosine_report --gzip on chromosome 3, then
   restriction to the interval with original coordinates and counts. No
   extra per-base quality filter or M-bias masking.
8. Positions, strands, trinucleotides and contexts validated against
   TAIR10; integer counts and gzip integrity checked.

Counts were not corrected for Wa-1 sequence variants or re-estimated
conversion efficiency.

SOURCES

ENA runs SRR11805321 and SRR11805322; project PRJNA633425.
Reference: Ensembl Plants release 62, Arabidopsis_thaliana.TAIR10.dna.toplevel.fa.gz.
Software: fastp 1.4.0, Bismark 0.25.1, Bowtie2 2.5.5, Samtools 1.24, Edlib 1.2.7.
Bondada R. et al. (2020). Natural epialleles of Arabidopsis SUPERMAN display
superwoman phenotypes. Communications Biology 3, 772.
https://doi.org/10.1038/s42003-020-01525-9
